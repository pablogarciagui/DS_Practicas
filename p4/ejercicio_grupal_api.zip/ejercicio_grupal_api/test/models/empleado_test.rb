require "test_helper"

class EmpleadoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
