class EjercicioDsController < ApplicationController
end
