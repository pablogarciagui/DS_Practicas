enum TipoBuilder {
  completo('Tiempo Completo'),
  parcial('Medio Tiempo');

  const TipoBuilder(this.label);
  final String label;
}