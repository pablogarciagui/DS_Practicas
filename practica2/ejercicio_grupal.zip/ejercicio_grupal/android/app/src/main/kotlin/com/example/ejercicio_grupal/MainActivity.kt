package com.example.ejercicio_grupal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
