class EmpleadoController < ApplicationController

    def index
        @empleados = Empleado.all
        logger.info "Cargando empleados para usuario #{params[:usuario]}, Total: #{@empleados.count}"
        render json: @empleados
    end

    def create
        @empleado = Empleado.new(empleado_params)
        if @empleado.save
            render json: @empleado, statur: :created
        else
            render json: @empleado.errors, status: :unprocessable_entity
        end
    end

    def update
        @empleado = Empleado.find(params[:dni])
        if @empleado.update(empleado_params)
            render json: @empleado
        else
            render json: @empleado.errors, status: :unprocessable_entity
        end
    end

    def destroy
        @empleado = Empleado.find(params[:dni])
        if empleado.destroy
            head :ok
        else
            render json: { error: "Failed to delete" }, status: :unprocessable_entity
        end
    end

    private

    def empleado_params
        params.require(:empleado).permit(:nombre, :dni, :dep_superior, :usuario)
    end

end
