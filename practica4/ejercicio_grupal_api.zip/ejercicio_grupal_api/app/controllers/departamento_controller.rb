class DepartamentoController < ApplicationController
    def index
        @departamentos = Departamento.all
        logger.info "Cargando departamentos para usuario #{params[:usuario]}, Total: #{@departamentos.count}"
        render json: @departamentos
    end

    def create
        @departamento = Departamento.new(deparatamento_params)
        if @departamento.save
            render json: @departamento, statur: :created
        else
            render json: @departamento.errors, status: :unprocessable_entity
        end
    end

    def update
        @departamento = Departamento.find(params[:id])
        if @departamento.update(deparatamento_params)
            render json: @departamento
        else
            render json: @departamento.errors, status: :unprocessable_entity
        end
    end

    def destroy
        @departamento = Departamento.find(params[:id])
        if departamento.destroy
            head :ok
        else
            render json: { error: "Failed to delete" }, status: :unprocessable_entity
        end
    end

    private

    def deparatamento_params
        params.require(:departamento).permit(:nombre, :dep_superior, :usuario)
    end
end
