class Departamento < ApplicationRecord
end
