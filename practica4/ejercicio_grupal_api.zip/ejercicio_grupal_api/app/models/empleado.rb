class Empleado < ApplicationRecord
end
