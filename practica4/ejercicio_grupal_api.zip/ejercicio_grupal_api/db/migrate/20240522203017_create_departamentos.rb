class CreateDepartamentos < ActiveRecord::Migration[7.1]
  def change
    create_table :departamentos do |t|
      t.string :nombre
      t.integer :dep_superior
      t.string :usuario

      t.timestamps
    end
  end
end
