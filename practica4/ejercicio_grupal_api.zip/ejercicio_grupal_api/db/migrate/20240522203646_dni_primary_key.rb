class DniPrimaryKey < ActiveRecord::Migration[7.1]
  def change
    change_table :empleados do |t|
      t.remove :id
      t.primary_key :dni
    end
  end
end
